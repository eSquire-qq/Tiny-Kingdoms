package com.artem.rtsserver.match;

public class AIController {

    private final int aiPlayerId;

    private float thinkTimer = 0f;
    private float scoutTimer = 0f;
    private float trainTimer = 0f;

    private AIState state = AIState.SCOUT;

    private Integer knownEnemyBuildingId = null;
    private Integer knownEnemyUnitId = null;

    private final Difficulty difficulty;

    private float visionRange;
    private int minAttackArmy;
    private int maxArmy;
    private float thinkInterval;
    private float trainInterval;
    
    public AIController(int aiPlayerId, Difficulty difficulty) {
        this.aiPlayerId = aiPlayerId;
        this.difficulty = difficulty;

        switch (difficulty) {
            case EASY -> {
                visionRange = 4f;
                minAttackArmy = 4;
                maxArmy = 5;
                thinkInterval = 2.5f;
                trainInterval = 7f;
            }
            case NORMAL -> {
                visionRange = 6f;
                minAttackArmy = 3;
                maxArmy = 7;
                thinkInterval = 1.5f;
                trainInterval = 5f;
            }
            case HARD -> {
                visionRange = 8f;
                minAttackArmy = 2;
                maxArmy = 10;
                thinkInterval = 0.8f;
                trainInterval = 3f;
            }
        }
    }

    private enum AIState {
        SCOUT,
        BUILD_ARMY,
        ATTACK,
        DEFEND
    }
    
    public enum Difficulty {
        EASY,
        NORMAL,
        HARD
    }
    
    

    public void update(GameSession session, float dt) {

        thinkTimer += dt;
        scoutTimer += dt;
        trainTimer += dt;

        if (thinkTimer < thinkInterval)
            return;

        thinkTimer = 0f;

        PlayerState ai = session.getPlayersState().get(aiPlayerId);

        if (ai == null)
            return;

        checkVision(session);

        switch (state) {

            case SCOUT:
                updateScout(session);
                break;

            case BUILD_ARMY:
                updateBuildArmy(session, ai);
                break;

            case ATTACK:
                updateAttack(session);
                break;

            case DEFEND:
                updateDefend(session);
                break;
        }
    }

    private void updateScout(GameSession session) {

        if (knownEnemyBuildingId != null ||
                knownEnemyUnitId != null) {

            state = AIState.BUILD_ARMY;

            System.out.println("[AI] Enemy found -> BUILD_ARMY");

            return;
        }

        if (scoutTimer < 4f)
            return;

        scoutTimer = 0f;

        for (UnitState u : session.getUnits().values()) {

            if (u.getOwnerPlayerId() != aiPlayerId)
                continue;

            if ("worker".equals(u.getUnitType()))
                continue;

            // move scout to player base
            u.setTarget(0f, 0f);

            System.out.println("[AI] Scout unit " + u.getId());
            break;
        }
    }

    private void updateBuildArmy(
            GameSession session,
            PlayerState ai
    ) {

        int armyCount = countCombatUnits(session);

        if (armyCount >= minAttackArmy) {

            state = AIState.ATTACK;

            System.out.println("[AI] Army ready -> ATTACK");

            return;
        }

        if (trainTimer < trainInterval)
            return;

        trainTimer = 0f;

        if (armyCount >= maxArmy)
            return;

        for (BuildingState b : session.getBuildings().values()) {

            if (b.getOwnerPlayerId() != aiPlayerId)
                continue;

            // train swordsman

            if ("barracks".equals(b.getBuildingType())) {

                UnitStats stats =
                        session.getUnitStats("swordsman");

                if (stats == null)
                    continue;

                if (!ai.hasEnoughResources(
                        stats.getGoldCost(),
                        stats.getLumberCost()))
                    continue;

                if (!ai.hasEnoughSupply(
                        stats.getSupplyCost()))
                    continue;

                ai.spendResources(
                        stats.getGoldCost(),
                        stats.getLumberCost());

                b.enqueueUnit("swordsman");

                System.out.println("[AI] Training swordsman");
            }

            // train archer

            if ("archery".equals(b.getBuildingType())) {

                UnitStats stats =
                        session.getUnitStats("archer");

                if (stats == null)
                    continue;

                if (!ai.hasEnoughResources(
                        stats.getGoldCost(),
                        stats.getLumberCost()))
                    continue;

                if (!ai.hasEnoughSupply(
                        stats.getSupplyCost()))
                    continue;

                ai.spendResources(
                        stats.getGoldCost(),
                        stats.getLumberCost());

                b.enqueueUnit("archer");

                System.out.println("[AI] Training archer");
            }
        }
    }


    private void updateAttack(GameSession session) {

        if (knownEnemyBuildingId == null &&
                knownEnemyUnitId == null) {

            state = AIState.SCOUT;

            System.out.println("[AI] Lost enemy -> SCOUT");

            return;
        }

        for (UnitState u : session.getUnits().values()) {

            if (u.getOwnerPlayerId() != aiPlayerId)
                continue;

            if ("worker".equals(u.getUnitType()))
                continue;

            if (knownEnemyBuildingId != null) {

                u.setAttackTarget(knownEnemyBuildingId);
                u.setAttackTargetIsBuilding(true);

            } else if (knownEnemyUnitId != null) {

                u.setAttackTarget(knownEnemyUnitId);
                u.setAttackTargetIsBuilding(false);
            }
        }
    }
    
    private void updateDefend(GameSession session) {

        for (UnitState enemy : session.getUnits().values()) {

            if (enemy.getOwnerPlayerId() == aiPlayerId)
                continue;

            for (UnitState aiUnit : session.getUnits().values()) {

                if (aiUnit.getOwnerPlayerId() != aiPlayerId)
                    continue;

                if ("worker".equals(aiUnit.getUnitType()))
                    continue;

                aiUnit.setAttackTarget(enemy.getId());
                aiUnit.setAttackTargetIsBuilding(false);
            }
        }
    }

    private void checkVision(GameSession session) {

        knownEnemyBuildingId = null;
        knownEnemyUnitId = null;

        for (UnitState aiUnit : session.getUnits().values()) {

            if (aiUnit.getOwnerPlayerId() != aiPlayerId)
                continue;

            for (BuildingState b : session.getBuildings().values()) {

                if (b.getOwnerPlayerId() == aiPlayerId)
                    continue;

                float dx = b.getX() - aiUnit.getX();
                float dy = b.getY() - aiUnit.getY();

                float dist =
                        (float)Math.sqrt(dx * dx + dy * dy);

                if (dist <= visionRange) {

                    knownEnemyBuildingId = b.getId();

                    return;
                }
            }

            for (UnitState enemy : session.getUnits().values()) {

                if (enemy.getOwnerPlayerId() == aiPlayerId)
                    continue;

                float dx = enemy.getX() - aiUnit.getX();
                float dy = enemy.getY() - aiUnit.getY();

                float dist =
                        (float)Math.sqrt(dx * dx + dy * dy);

                if (dist <= visionRange) {

                    knownEnemyUnitId = enemy.getId();

                    return;
                }
            }
        }
    }

    private int countCombatUnits(GameSession session) {

        int count = 0;

        for (UnitState u : session.getUnits().values()) {

            if (u.getOwnerPlayerId() != aiPlayerId)
                continue;

            if ("worker".equals(u.getUnitType()))
                continue;

            count++;
        }

        return count;
    }
}